﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalcu
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("Informe um número válido!");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out Numero2))
            {
                MessageBox.Show("Informe um número válido!");
                txtNumero2.Focus();
            }
        }


        private void btnadicao_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtResultado.Text = Resultado.ToString();
        }


        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtResultado.Text, out Numero2) || Numero2 == 0)
                MessageBox.Show("Não é possível dividir por 0");
            else
            {
                Resultado = Numero1 / Numero2;
                txtResultado.Text = Resultado.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear(); 
            txtResultado.Clear();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
           Application.Exit();
        }
    }
}
