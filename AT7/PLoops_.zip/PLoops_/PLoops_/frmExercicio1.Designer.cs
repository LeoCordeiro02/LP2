﻿namespace PLoops_
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnPar = new System.Windows.Forms.Button();
            this.BtnQntR = new System.Windows.Forms.Button();
            this.BtnEspaços = new System.Windows.Forms.Button();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // BtnPar
            // 
            this.BtnPar.Location = new System.Drawing.Point(351, 97);
            this.BtnPar.Name = "BtnPar";
            this.BtnPar.Size = new System.Drawing.Size(120, 48);
            this.BtnPar.TabIndex = 8;
            this.BtnPar.Text = "Quantidade de vezes da ocorrencia do par de letras";
            this.BtnPar.UseVisualStyleBackColor = true;
            this.BtnPar.Click += new System.EventHandler(this.BtnPar_Click);
            // 
            // BtnQntR
            // 
            this.BtnQntR.Location = new System.Drawing.Point(189, 97);
            this.BtnQntR.Name = "BtnQntR";
            this.BtnQntR.Size = new System.Drawing.Size(120, 48);
            this.BtnQntR.TabIndex = 7;
            this.BtnQntR.Text = "Quantidade de vezes da aparição do R ";
            this.BtnQntR.UseVisualStyleBackColor = true;
            this.BtnQntR.Click += new System.EventHandler(this.BtnQntR_Click);
            // 
            // BtnEspaços
            // 
            this.BtnEspaços.Location = new System.Drawing.Point(24, 97);
            this.BtnEspaços.Name = "BtnEspaços";
            this.BtnEspaços.Size = new System.Drawing.Size(120, 48);
            this.BtnEspaços.TabIndex = 6;
            this.BtnEspaços.Text = "Quantidade de espaços em branco";
            this.BtnEspaços.UseVisualStyleBackColor = true;
            this.BtnEspaços.Click += new System.EventHandler(this.BtnEspaços_Click);
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchtxtFrase.Location = new System.Drawing.Point(24, 42);
            this.rchtxtFrase.MaxLength = 100;
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(557, 27);
            this.rchtxtFrase.TabIndex = 5;
            this.rchtxtFrase.Text = "";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnPar);
            this.Controls.Add(this.BtnQntR);
            this.Controls.Add(this.BtnEspaços);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnPar;
        private System.Windows.Forms.Button BtnQntR;
        private System.Windows.Forms.Button BtnEspaços;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
    }
}