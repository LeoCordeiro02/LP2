﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops_
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalin_Click(object sender, EventArgs e)
        {
            string fraseOriginal = txtPalindromo.Text;

            if (fraseOriginal.Length > 50)
            {
                MessageBox.Show("Necessário menos de 50 caracteres.");
                return;
            }

            string fraseLimpa = Regex.Replace(fraseOriginal, @"\s+", "").ToLower();

            string fraseInvertida = new string(fraseLimpa.Reverse().ToArray());

           
            if (fraseLimpa == fraseInvertida)
            {
                MessageBox.Show("É palíndromo");
            }
            else
            {
                MessageBox.Show("Não é palíndromo.");
            }
        }
    }
}




