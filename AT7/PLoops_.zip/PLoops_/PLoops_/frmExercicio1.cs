﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops_
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void BtnEspaços_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text;
            int contador = 0;

            for (int i = 0; i < frase.Length; i++)
            {
                if (frase[i] == ' ')
                {
                    contador++;
                }
            }
            MessageBox.Show("Há " + contador + " espaços em branco");

        }

        private void BtnQntR_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text;
            int contador = 0;
            int i = 0;

            while (i < frase.Length)
            {
                string FraseMaisc = frase.ToUpper();
                if (FraseMaisc[i] == 'R')
                {
                    contador++;
                }
                i++;
            }
            MessageBox.Show("Há " + contador + " letras 'R' na frase");
        }

        private void BtnPar_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text;
            int contador = 0;
            int i = 0;

            if (frase.Length > 1)
            {
                do
                {
                    if (frase[i] == frase[i + 1])
                    {
                        contador++;
                    }
                    i++;
                }
                while (i < frase.Length - 1);
            }
            MessageBox.Show("Ocorre o par de letras " + contador + " vezes");
        }
    }
}
