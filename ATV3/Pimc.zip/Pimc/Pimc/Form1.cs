﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double peso, altura, imc;

        private void mskbxPeso_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Peso Inválido");
                e.Cancel = true;
            }
        }

        private void mskbxAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida");
                e.Cancel = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            txtImc.Text = imc.ToString();
            if (imc < 18.5)
            {
                MessageBox.Show("Magreza"); 
            }
            else if (imc <= 24.9)
            { 
                MessageBox.Show("Normal");
            }
            else if (imc <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (imc <= 39.9)
            {
                MessageBox.Show("Obesidade");
            }
            else
            {
                MessageBox.Show("Obesidade Grave");
            }
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        
    }
}
