﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividades8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] numeros = new int[20];

            for (int i = 0; i < 20; i++)
            {
                bool valido = false;

                while (!valido)
                {
                    string entrada = Interaction.InputBox($"Digite o {i + 1}º número inteiro:", "Entrada de Números");

                    if (int.TryParse(entrada, out numeros[i]))
                    {
                        valido = true;
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido. Digite um número inteiro.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            string resultado = "Números em ordem inversa:\n\n";

            for (int i = numeros.Length - 1; i >= 0; i--)
            {
                resultado += numeros[i] + "\n";
            }

            MessageBox.Show(resultado, "Resultado");
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList()
            {
                "Ana", "André", "Beatriz", "Camila", "João",
                "Joana", "Otávio", "Marcelo", "Pedro", "Thais"
            };


            alunos.Remove("Otávio");


            string resultado = "Alunos:\n\n";
            foreach (string nome in alunos)
            {
                resultado += nome + "\n";
            }

            MessageBox.Show(resultado, "Lista de Alunos");
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string resultado = "";

            for (int i = 0; i < 20; i++)
            {
                double soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    double nota;
                    string entrada;

                    do
                    {
                        entrada = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1} (0 a 10):", "Entrada de Nota");
                    }
                    while (!double.TryParse(entrada, out nota) || nota < 0 || nota > 10);

                    notas[i, j] = nota;
                    soma += nota;
                }

                double media = soma / 3;
                resultado += $"Aluno {i + 1}: média {media:F1}\n";
            }

            MessageBox.Show(resultado, "Médias dos Alunos");
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                frmExercicio4 obj4 = new frmExercicio4(); // crio o objeto do novo formulario
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio5"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                frmExercicio5 obj5 = new frmExercicio5(); // crio o objeto do novo formulario
                obj5.WindowState = FormWindowState.Maximized;
                obj5.Show();
            }
        }
    }
}




   
