﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividades8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanhos = new int[10];

            listBox1.Items.Clear(); // limpa antes de adicionar

            for (int i = 0; i < 10; i++)
            {
                string nome;
                do
                {
                    nome = Interaction.InputBox($"Digite o nome completo da pessoa {i + 1}:", "Entrada de Nome").Trim();
                }
                while (string.IsNullOrWhiteSpace(nome));

                nomes[i] = nome;
                tamanhos[i] = nome.Replace(" ", "").Length;

                listBox1.Items.Add($"O nome {nomes[i]} tem {tamanhos[i]} caracteres");
            }
        }
    }
}
