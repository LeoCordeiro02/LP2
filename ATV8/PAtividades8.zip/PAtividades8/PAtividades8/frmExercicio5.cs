﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividades8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[] gabarito = { 'A', 'C', 'B', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };

            int N = 1;

            char[,] respostas = new char[N, 10];

            for (int aluno = 0; aluno < N; aluno++)
            {
                for (int questao = 0; questao < 10; questao++)
                {
                    char resposta;
                    do
                    {
                        string input = Interaction.InputBox($"Aluno {aluno + 1} - Questão {questao + 1} (A/B/C/D/E):", "Resposta");
                        if (string.IsNullOrWhiteSpace(input) || !"ABCDE".Contains(input.ToUpper()))
                        {
                            MessageBox.Show("Digite apenas A, B, C, D ou E.");
                            resposta = '\0';
                        }
                        else
                        {
                            resposta = char.ToUpper(input[0]);
                        }
                    } while (resposta == '\0');

                    respostas[aluno, questao] = resposta;
                }
            }


            string mensagem = "";

            for (int aluno = 0; aluno < N; aluno++)
            {
                int acertos = 0;
                mensagem += $"Aluno {aluno + 1}:\n";

                for (int questao = 0; questao < 10; questao++)
                {
                    char resp = respostas[aluno, questao];
                    char certa = gabarito[questao];

                    if (resp == certa)
                        acertos++;

                    mensagem += $"Questão {questao + 1}: escolheu {resp} (certa {certa})\n";
                }

                mensagem += $"Total de acertos: {acertos}\n\n";
            }

            MessageBox.Show(mensagem, "Resultado das Respostas");
        }
    }
}

        
    

