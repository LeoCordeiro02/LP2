﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Microsoft.VisualBasic;

namespace PEstoque1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] MatrizInt = new double[2, 4];
            string auxiliar = "";
            double cont = 0;
            int novc;


            for (int j = 0; j < 4; j++)
            {

                for (int i = 0; i < 1; i++)
                {

                    auxiliar = Interaction.InputBox($"Informe a quantidade de entradas do produto 1 na {j + 1}ª semana");
                    if (Double.TryParse(auxiliar, out MatrizInt[i, j]) && MatrizInt[i, j] <= 0 || MatrizInt[i, j] > 10)
                    {
                        MessageBox.Show("Nota Invalida");
                        j--;
                    }
                    else
                    {
                        cont += MatrizInt[i, j];
                    }
                }
					lstbxo.Items.Add($"{i + 1} a {j + 1}: " + ]);
        private void button2_Click(object sender, EventArgs e)
        {
            
        }
        // dava dando certo mas eu perdi o desing total ai tive que ir dando ctrl + z     ;(
    }
}
